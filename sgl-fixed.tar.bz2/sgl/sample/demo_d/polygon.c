#include	"sgl.h"

static POINT point_CUBE[]={
	POStoFIXED(-15.000000, -15.000000,  15.000000),
	POStoFIXED( 15.000000, -15.000000,  15.000000),
	POStoFIXED( 15.000000,	15.000000,  15.000000),
	POStoFIXED(-15.000000,	15.000000,  15.000000),
	POStoFIXED(-15.000000, -15.000000, -15.000000),
	POStoFIXED( 15.000000, -15.000000, -15.000000),
	POStoFIXED( 15.000000,	15.000000, -15.000000),
	POStoFIXED(-15.000000,	15.000000, -15.000000),
};

static POLYGON polygon_CUBE[]={
	NORMAL( 0.000000, 0.000000, 1.000000), VERTICES(0,1,2,3),
	NORMAL(-1.000000, 0.000000, 0.000000), VERTICES(4,0,3,7),
	NORMAL( 0.000000, 0.000000,-1.000000), VERTICES(5,4,7,6),
	NORMAL( 1.000000, 0.000000, 0.000000), VERTICES(1,5,6,2),
	NORMAL( 0.000000,-1.000000, 0.000000), VERTICES(4,5,1,0),
	NORMAL( 0.000000, 1.000000, 0.000000), VERTICES(3,2,6,7),
};

static ATTR attribute_CUBE[]={
	ATTRIBUTE(Single_Plane,SORT_MIN,No_Texture,C_RGB(31,31,0),No_Gouraud,MESHoff,sprPolygon,UseLight),
	ATTRIBUTE(Single_Plane,SORT_MIN,No_Texture,C_RGB(31,31,0),No_Gouraud,MESHoff,sprPolygon,UseLight),
	ATTRIBUTE(Single_Plane,SORT_MIN,No_Texture,C_RGB(31,31,0),No_Gouraud,MESHoff,sprPolygon,UseLight),
	ATTRIBUTE(Single_Plane,SORT_MIN,No_Texture,C_RGB(31,31,0),No_Gouraud,MESHoff,sprPolygon,UseLight),
	ATTRIBUTE(Single_Plane,SORT_MIN,No_Texture,C_RGB(31,31,0),No_Gouraud,MESHoff,sprPolygon,UseLight),
	ATTRIBUTE(Single_Plane,SORT_MIN,No_Texture,C_RGB(31,31,0),No_Gouraud,MESHoff,sprPolygon,UseLight),
};

PDATA PD_CUBE = {
	point_CUBE,sizeof(point_CUBE)/sizeof(POINT),
	polygon_CUBE,sizeof(polygon_CUBE)/sizeof(POLYGON),
	attribute_CUBE
};

