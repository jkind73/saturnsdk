
	global	SEGA_MARK

SEGA_MARK:	dc.l	53454741H
	end

