
#define	SEGA2D_MAP	"scroll/vf.map"
#define	SEGA2D_CEL	"scroll/vf.cel"
#define	SEGA2D_PAL	"scroll/vf.pal"

#define	SEGA2D_H	"scroll/vf.h"


