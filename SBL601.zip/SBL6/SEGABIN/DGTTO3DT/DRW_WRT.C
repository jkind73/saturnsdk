/*------------------------------------------------------------------------
 *  FILE: drw_wrt.c
 *      $Author: $
 *      $Date: $
 *      $Locker: $
 *      $Revision: $
 *      $Source: $
 *      $State: $
 *
 *      Copyright (c) by SEGA Enterprises Ltd. 1994. All rights reserved.
 *
 *  PURPOSE:
 *		DGT or RGB to 3D Table conversion program
 *
 *  DESCRIPTION:
 *		Write DRAW/COLOR information for texture
 *
 *  INTERFACE
 *
 *
 *  CAVEATS
 *
 *
 *  AUTHOR(S):
 *		K. Hasuike	(ssdg)
 *
 *  MOD HISTORY:
 *      $Log: $
 * 
 * 
 *------------------------------------------------------------------------
 */

#include "dgtto3dt.h"

void
drw_wrt()

{
	static	Sint8	string[120];
	static	Sint8	buf[100];
	Sint16	i, j;
	Sint16	x;
	Sint16	plt_max_no, flg;
	FILE	*fppo;

	/* �o�̓t�@�C���I�[�v���i�ǉ����[�h�j */
	fppo = fopen ( g_c_outname, "a" );
	if ( fppo != NULL ){

		/* �c�q�`�v�^�b�n�k�n�q��� */
		for ( i = 1; i < g_tex_max+1; i++ ){

			/* �c�q�`�v */
			strcpy(string,"#define DRAW");
			strcat(string,mbuf[i].mat_nam);
			if ( g_spd_mod == 0 ) {
				strcat(string,DRAW_DEF_T);
			} else {
				strcat(string,DRAW_DEF_S);
			}
			if ( g_col_mod == 0 )
				strcat(string," | COLOR_0");
			if ( g_col_mod == 1 )
				strcat(string," | COLOR_1");
			if ( g_col_mod == 2 )
				strcat(string," | COLOR_2");
			if ( g_col_mod == 3 )
				strcat(string," | COLOR_3");
			if ( g_col_mod == 4 )
				strcat(string," | COLOR_4");
			if ( g_col_mod == 5 )
				strcat(string," | COLOR_5");
			if ( mbuf[i].type&0x0001 == 1 )
				strcat(string," | DRAW_MESH");
			if ( mbuf[i].type < 2 ){
				strcat(string," | COMPO_REP");
			}else{
				if( mbuf[i].type&0x0002 == 2 )
					strcat(string," | COMPO_HARF");
				if( mbuf[i].type&0x0004 == 4 )
					strcat(string," | COMPO_TRANS");
			}
			strcat(string,"\n");
			fputs(string,fppo);

			/* �b�n�k�n�q */
			strcpy(string,"#define COLOR");
			strcat(string,mbuf[i].mat_nam);
			strcat(string," ");
			sprintf(buf,"%d",mbuf[i].mode);
			strcat(string,buf);
			strcat(string,"\n");
			fputs(string,fppo);

		}
		fputs("\n",fppo);

		/* �e�N�X�`���e�[�u���{�� */
		fputs("static SprTexture Texture[] = {\n",fppo);
		for ( i = 0; i < g_tex_cnt; i++ ){

			/* �J�n���� */
			fputs("    {\n",fppo);

			/* �L�����N�^�m���D */
			fprintf(fppo,"/* character no.        */ %d,\n",txt[i].char_no);

			/* �J���[���[�h */
			strcpy(string,"/* color mode           */ ");
			if ( g_col_mod == 0 ) strcat(string,"COLOR_0");
			if ( g_col_mod == 1 ) strcat(string,"COLOR_1");
			if ( g_col_mod == 2 ) strcat(string,"COLOR_2");
			if ( g_col_mod == 3 ) strcat(string,"COLOR_3");
			if ( g_col_mod == 4 ) strcat(string,"COLOR_4");
			if ( g_col_mod == 5 ) strcat(string,"COLOR_5");
			strcat(string,",\n");
			fputs(string,fppo);

			/* �J���[ */
			fprintf(fppo,"/* color data           */ %d,\n",i);

			/* �L�����N�^�� */
			fprintf(fppo,"/* character width      */ %d,\n",txt[i].width);

			/* �L�����N�^�� */
			fprintf(fppo,"/* character height     */ %d,\n",txt[i].height);

			/* �L�����N�^�|�C���^ */
			strcpy(string,"/* character pointer    */ (Uint8 *)");

			/* �u.�v�܂ł̕�����𒊏o */
			for ( j = 0; j < 80; j++ ){
				if ( txt[i].chr_nam[j] != '.' ) {
					buf[j] = txt[i].chr_nam[j];
				}else{
					buf[j] = NULL;
					break;
				}
			}
			strcat(string,buf);
			strcat(string,",\n");
			fputs(string,fppo);

			/* ���b�N�A�b�v�e�[�u���|�C���^ */
			strcpy(string,"/* lookup table pointer */ ");
			if ( g_col_mod == 1 ){
				strcat(string,"(SprLookupTbl *)");
				strcat(string,g_col_tbl);
				strcat(string,"_");
				sprintf(buf,"%d",i);
				strcat(string,buf);
			}else{
				strcat(string,"NULL");
			}
			strcat(string,"\n");
			fputs(string,fppo);

			/* �I������ */
			fputs("    },\n",fppo);

		}
		/* �X�g�b�v�f�[�^ */
		fputs("    {\n",fppo);
		fputs("/*                      */ 0xffff,\n",fppo);
		/* �J���[���[�h�͒��O�̃f�[�^�𗬗p */
		strcpy(string,"/* stop data            */ ");
		if ( g_col_mod == 0 ) strcat(string,"COLOR_0");
		if ( g_col_mod == 1 ) strcat(string,"COLOR_1");
		if ( g_col_mod == 2 ) strcat(string,"COLOR_2");
		if ( g_col_mod == 3 ) strcat(string,"COLOR_3");
		if ( g_col_mod == 4 ) strcat(string,"COLOR_4");
		if ( g_col_mod == 5 ) strcat(string,"COLOR_5");
		strcat(string,",\n");
		fputs(string,fppo);
		fputs("/*                      */ 0,\n",fppo);
		fputs("/*                      */ 0,\n",fppo);
		fputs("/*                      */ 0,\n",fppo);
		fputs("/*                      */ NULL,\n",fppo);
		fputs("/*                      */ NULL\n",fppo);
		fputs("    }\n",fppo);

		/* �I������ */
		fputs("};\n",fppo);
		fputs("\n",fppo);



	/* �o�̓t�@�C���N���[�Y */
	fclose ( fppo );

	}


	/* Data Dump Section */
	/*printf("plt_max_no = %d\n",plt_max_no);
	for ( x = 0; x < g_plt_max; x+=2 ){
		printf("plt_no = %x : color = %x\n",
			g_pltdata[x],g_pltdata[x+1]);
	}*/
}
