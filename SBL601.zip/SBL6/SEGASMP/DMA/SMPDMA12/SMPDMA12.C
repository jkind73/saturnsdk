/****************************************************************************/
/*  filename "smpdma12.c"                                                   */
/*  �c�l�`�T���v���v���O����                                                */
/*  Copyright(c) 1994 SEGA                                                  */
/*  Written by N.T on 1994-05-17 Ver.0.90                                   */
/*  Updated by N.T on 1994-10-12 Ver.0.90                                   */
/****************************************************************************/
#include <stdio.h>
#include <string.h>
#include "sega_xpt.h"
#include "sega_dma.h"
#include "sega_int.h"

static Sint8 *pbuf;                         /*  ���ʊi�[�o�b�t�@�|�C���^    */

Uint32 hikaku(void *, void *, Uint32, Uint32, Sint8 *); /*  ���ʊm�F�֐�    */
void rev(void *, void *, Uint32, Uint32);   /*  �]����f�[�^�j��֐�        */

void main(void)
{
    void *src, *dst;
    Uint32 cnt;

    DMA_ScuInit();                          /* SCU DMA�̏�����              */

    pbuf = (Sint8 *)0x06040000;             /*  ���ʊi�[�擪�A�h���X        */
    dst = (void *)0x25c00000;
    src = (void *)0x6050000;
    cnt = 0x500;

    rev(src, dst, cnt, 1);
    DMA_ScuMemCopy(dst, src, cnt);
    while(DMA_SCU_END != DMA_ScuResult());
    hikaku(src, dst, cnt, 1, "WORK to VDP1");

    for(;;) ;
}
/****************************************************************************/
/*  ���ʔ�r�֐�                                                            */
/****************************************************************************/
Uint32 hikaku(void *src, void *dst, Uint32 cnt, Uint32 size, Sint8 *msg)
{
#if	0
	/*
	**��1995-07-28	�����q��
	**	�g���ĂȂ��̂ō폜
	*/
    Uint32 i, p;
#else
	Uint32	i;
#endif
    
#if	0
	/*
	**��1995-07-28	�����q��
	**	long �ȃI�u�W�F�N�g�� %X �ł͂Ȃ� %lX
	**	�|�C���^�̒l�����̂܂ܕ\�����悤�Ƃ��Ă���̂� ( Uint32 ) �ɃL���X�g
	*/
    sprintf(pbuf, "[[ \'%s\' %08X >> %08X : %08X Count, %01X Byte ",
     msg, src, dst, cnt, size);
#else
    sprintf(pbuf, "[[ \'%s\' %08lX >> %08lX : %08lX Count, %01lX Byte ",
     msg, ( Uint32 )src, ( Uint32 )dst, cnt, size);
#endif
    pbuf += strlen(pbuf);
    for(i = 0; i < cnt; i++) {
        switch(size) {
            case 1:
                if(*(Uint8 *)dst != *(Uint8 *)src) {
#if	0
	/*
	**��1995-07-28	�����q��
	**	long �ȃI�u�W�F�N�g�� %X �ł͂Ȃ� %lX
	**	�|�C���^�̒l�����̂܂ܕ\�����悤�Ƃ��Ă���̂� ( Uint32 ) �ɃL���X�g
	*/
                    sprintf(pbuf, "Error %08X(%02X,%02X) ]] \n",
                     dst, *(Uint8 *)src, *(Uint8 *)dst);
#else
                    sprintf(pbuf, "Error %08lX(%02X,%02X) ]] \n",
                     ( Uint32 )dst, *(Uint8 *)src, *(Uint8 *)dst);
#endif
                    pbuf += strlen(pbuf);
                    return 1;
                }
                break;
            case 2:
                if(*(Uint16 *)dst != *(Uint16 *)src) {
#if	0
	/*
	**��1995-07-28	�����q��
	**	long �ȃI�u�W�F�N�g�� %X �ł͂Ȃ� %lX
	**	�|�C���^�̒l�����̂܂ܕ\�����悤�Ƃ��Ă���̂� ( Uint32 ) �ɃL���X�g
	*/
                    sprintf(pbuf, "Error %08X(%04X,%04X) ]] \n",
                     dst, *(Uint16 *)src, *(Uint16 *)dst);
#else
                    sprintf(pbuf, "Error %08lX(%04X,%04X) ]] \n",
                     ( Uint32 )dst, *(Uint16 *)src, *(Uint16 *)dst);
#endif
                    pbuf += strlen(pbuf);
                    return 1;
                }
                break;
            case 4:
                if(*(Uint32 *)dst != *(Uint32 *)src) {
#if	0
	/*
	**��1995-07-28	�����q��
	**	long �ȃI�u�W�F�N�g�� %X �ł͂Ȃ� %lX
	**	�|�C���^�̒l�����̂܂ܕ\�����悤�Ƃ��Ă���̂� ( Uint32 ) �ɃL���X�g
	*/
                    sprintf(pbuf, "Error %08X(%08X,%08X) ]] \n",
                     dst, *(Uint32 *)src, *(Uint32 *)dst);
#else
                    sprintf(pbuf, "Error %08lX(%08lX,%08lX) ]] \n",
                     ( Uint32 )dst, *(Uint32 *)src, *(Uint32 *)dst);
#endif
                    pbuf += strlen(pbuf);
                    return 1;
                }
                break;
            case 16:
                if((*(Uint32 *)dst != *(Uint32 *)src)
                 || (*((Uint32 *)dst + 1) != *((Uint32 *)src + 1))
                 || (*((Uint32 *)dst + 2) != *((Uint32 *)src + 2))
                 || (*((Uint32 *)dst + 3) != *((Uint32 *)src + 3))) {
#if	0
	/*
	**��1995-07-28	�����q��
	**	long �ȃI�u�W�F�N�g�� %X �ł͂Ȃ� %lX
	**	�|�C���^�̒l�����̂܂ܕ\�����悤�Ƃ��Ă���̂� ( Uint32 ) �ɃL���X�g
	*/
                    sprintf(pbuf,
                     "Error %08X(%08X%08X%08X%08X,%08X%08X%08X%08X) ]] \n",
                      dst, *(Uint32 *)src, *(Uint32 *)((Uint32)src + 4),
                      *(Uint32 *)((Uint32)src + 8),
                      *(Uint32 *)((Uint32)src + 12),
                      *(Uint32 *)dst, *(Uint32 *)((Uint32)dst + 4),
                      *(Uint32 *)((Uint32)dst + 8),
                      *(Uint32 *)((Uint32)dst + 12));
#else
                    sprintf(pbuf,
                     "Error %08lX(%08lX%08lX%08lX%08lX,%08lX%08lX%08lX%08lX) ]] \n",
                      ( Uint32 )dst, *(Uint32 *)src, *(Uint32 *)((Uint32)src + 4),
                      *(Uint32 *)((Uint32)src + 8),
                      *(Uint32 *)((Uint32)src + 12),
                      *(Uint32 *)dst, *(Uint32 *)((Uint32)dst + 4),
                      *(Uint32 *)((Uint32)dst + 8),
                      *(Uint32 *)((Uint32)dst + 12));
#endif
                    pbuf += strlen(pbuf);
                    return 1;
                }
                i += 3;
                break;
            default:
                break;
        }
        dst = (void *)((Uint32)dst + size);
        src = (void *)((Uint32)src + size);
    }
    sprintf(pbuf, "OK ]] \n");
    pbuf += strlen(pbuf);
    return 0;
}

/****************************************************************************/
/*  �]������e�j��֐�                                                      */
/****************************************************************************/
void rev(void *src, void *dst, Uint32 cnt, Uint32 size)
{
    Uint32 i;
    
    for(i = 0; i < cnt; i++) {
        switch(size) {
            case 1:
                *(Uint8 *)dst = ~*(Uint8 *)src;
                break;
            case 2:
                *(Uint16 *)dst = ~*(Uint16 *)src;
                break;
            case 4:
                *(Uint32 *)dst = ~*(Uint32 *)src;
                break;
            case 16:
                *(Uint32 *)dst = ~*(Uint32 *)src;
                *((Uint32 *)dst + 1) = ~*((Uint32 *)src + 1);
                *((Uint32 *)dst + 2) = ~*((Uint32 *)src + 2);
                *((Uint32 *)dst + 3) = ~*((Uint32 *)src + 3);
                i += 3;
                break;
            default:
                break;
        }
        src = (void *)((Uint32)src + size);
        dst = (void *)((Uint32)dst + size);
    }
}

/****************************************************************************/
/*  End of File                                                             */
/****************************************************************************/
