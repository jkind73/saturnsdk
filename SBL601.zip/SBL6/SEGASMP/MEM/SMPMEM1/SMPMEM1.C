/*-----------------------------------------------------------------------------
 *  FILE: smpmem1.c
 *
 *  Copyright(c) 1995 SEGA
 *
 *  PURPOSE:
 *
 *      �������T���v���v���O����
 *
 *  DESCRIPTION:
 *
 *      �������Ǘ������s���܂��B
 *
 *  INTERFACE:
 *
 *      < FUNCTIONS LIST >
 *
 *  CAVEATS:
 *
 *  AUTHOR(S)
 *
 *      1995-12-04  H.O Ver.0.90
 *
 *  MOD HISTORY:
 *
 *-----------------------------------------------------------------------------
 */

/*
 * C VIRTUAL TYPES DEFINITIONS
 */
#include <stdio.h>
#include <string.h>
#include "sega_xpt.h"

/*
 * USER SUPPLIED INCLUDE FILES
 */
#include "sega_mem.h"

/*
 * GLOBAL DECLARATIONS
 */

/*
 * LOCAL DEFINES/MACROS
 */

/*
 * STATIC DECLARATIONS
 */

/*
 * STATIC FUNCTION PROTOTYPE DECLARATIONS
 */

/******************************************************************************
 *
 * NAME:    main()      - ���C��
 *
 * PARAMETERS :
 *      �Ȃ�
 *
 * DESCRIPTION:
 *      ���C��
 *
 * PRECONDITIONS:
 *      �Ȃ��B
 *
 * POSTCONDITIONS:
 *      �Ȃ�
 *
 * CAVEATS:
 *      �Ȃ��B
 *
 ******************************************************************************
 */

#define	SZ_HEAP	0x1001
static unsigned char	__heap[SZ_HEAP];
char	sega[] = "SEGA";

void main(void){
	Uint32	biggest,ui;
	void	*ptr,*tmp;
	int	i,maxcell[32];
	char	*pc;

	/* 0����32�o�C�g�ōő傢���u���b�N���m�ۂł��邩 */
	for( i = 0 ; i < 32 ; i++){
		maxcell[i] = 0;
	    MEM_Init( ( Uint32 )__heap, sizeof( __heap ));
		while( ( (ptr = MEM_Malloc( i )) != NULL ) )
			maxcell[i]++;
	}

	/* �m�ۉ\�ȍő�T�C�Y�͊�� */
    MEM_Init( ( Uint32 )__heap, sizeof( __heap ));
	for( biggest = SZ_HEAP+15;
	(ptr = MEM_Malloc((Uint32)biggest)) == NULL;
	biggest-- )
		;
	MEM_Free( ptr );

	/* �ēx�m�ۉ\�� */
	while( (ptr = MEM_Malloc((Uint32)biggest)) == NULL )
		;
	MEM_Free( ptr );

	/* �A�����Ċm�� */
	tmp = NULL;
	for( i = 0;; i++ ){
		if( (ptr = MEM_Malloc((Uint32)(sizeof(void *)))) == NULL )
			break;
		else{
			*(void **)ptr = tmp;
			tmp = ptr;
		}
	}
	/* �A�����ĊJ�� */
	for( ptr = tmp ; ptr != NULL ; i--){
		tmp = *(void **)ptr;
		MEM_Free(ptr);
		ptr = tmp;
	}

	/* �z��̊m�� */
	while( (ptr = MEM_Calloc((Uint32)biggest/8,(Uint32)8)) == NULL )
		;
	for( ui = 0 ; ui < biggest ; ui++){
		pc = (char *)ptr;
		while( pc[ui] != 0 )
			;
	}
	MEM_Free( ptr );

	/* �A�����čĊ���t�� */
	ptr = MEM_Malloc((Uint32)(sizeof(char[4])));
	for( i = 0 ; i < 4 ; i ++ ){
#if 1
		pc = (char *)ptr;
		pc[i] = sega[i];
#else
		*(char *)(ptr + i) = sega[i];
#endif
	}
	for( i = 0 ; i < 0x100 ; i++ )
		ptr = MEM_Realloc( ptr, (Uint32)sizeof(char[4]) );

	/* �����܂ł���ΏI�� */
	for(;;)
		;
}
