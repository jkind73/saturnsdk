/****************************************
*			include files				*
****************************************/
#include	"sega_dbg.h"
#include	"per_x.h"

/****************************************
*		declare private objects			*
****************************************/
/*
**	device_name[]
**		�y���t�F�����f�o�C�X�̖��O�̃e�[�u��
**		�h�c���C���f�b�N�X�ɂ��ĎQ�Ƃ��܂��B
*/
static char	*device_name[] = {
	"DIGITAL ","DIGITAL ","DIGITAL ","DIGITAL ",
	"DIGITAL ","DIGITAL ","DIGITAL ","DIGITAL ",
	"DIGITAL ","DIGITAL ","DIGITAL ","DIGITAL ",
	"DIGITAL ","DIGITAL ","DIGITAL ","DIGITAL ",
	
	"ANALOGUE","ANALOGUE","ANALOGUE","ANALOGUE",
	"ANALOGUE","ANALOGUE","ANALOGUE","ANALOGUE",
	"ANALOGUE","ANALOGUE","ANALOGUE","ANALOGUE",
	"ANALOGUE","ANALOGUE","ANALOGUE","ANALOGUE",
	
	"POINTING","POINTING","POINTING","POINTING",
	"POINTING","POINTING","POINTING","POINTING",
	"POINTING","POINTING","POINTING","POINTING",
	"POINTING","POINTING","POINTING","POINTING",
	
	"KEYBOARD","KEYBOARD","KEYBOARD","KEYBOARD",
	"KEYBOARD","KEYBOARD","KEYBOARD","KEYBOARD",
	"KEYBOARD","KEYBOARD","KEYBOARD","KEYBOARD",
	"KEYBOARD","KEYBOARD","KEYBOARD","KEYBOARD",
	
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	
	"MD??????","MD3B    ","MD6B    ","MDMOUSE ",
	"MD??????","MD??????","MD??????","MD??????",
	"MD??????","MD??????","MD??????","MD??????",
	"MD??????","MD??????","MD??????","MD??????",
	
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","VR-GUN  ","UNKNOWN ",
	"UNKNOWN ","UNKNOWN ","UNKNOWN ","NONE    ",
};

/*@*/
/************************************************************************
*																		*
*	�ysynopsis�z														*
*																		*
*		display_device_info( device, x, y );							*
*																		*
*		�y���t�F�������C�u�����ɂ���Ď��W���ꂽ�f�[�^�̃_���v���o��	*
*		���܂��B														*
*																		*
*																		*
*	�yparameters�z														*
*																		*
*		const SysDevice	*device;										*
*		int			x,y;												*
*																		*
*		<device> �́A�y���t�F�����f�[�^�ւ̃|�C���^�iNULL �́A���ڑ��j	*
*		<x>, <y> �́A�\�����W�i���オ 0,0 �j							*
*																		*
*																		*
*	�yreturn value�z													*
*																		*
*		�Ȃ�															*
*																		*
*																		*
*	�yinfluence/reference objects�z										*
*																		*
*		device_name	reference	�y���t�F�����f�o�C�X�̖��O�̃e�[�u��	*
*								�h�c���C���f�b�N�X�ɂ��ĎQ�Ƃ��܂��B	*
*																		*
*																		*
************************************************************************/
void	display_device_info( const SysDevice	*device, int	x, int	y ){
	DBG_SetCursol( x, y );
	
	if( device == NULL ){
		DBG_Printf( "NONE     -- -- -- -- -- -- --" );
	}
	else{
		Uint8	*data = ( Uint8 * )device->data;
		int		id = PER_GetID( device );
		int		size  = PER_GetSize( device );
		char	*name = device_name[id];
		int		n = 0;
		
		DBG_Printf( "%s %02X", name, id );
		while( n < 6 ){
			if( n < size )
				DBG_Printf( " %02X", data[n] );
			else
				DBG_Printf( " --" );
			
			n++;
		}
	}
}

