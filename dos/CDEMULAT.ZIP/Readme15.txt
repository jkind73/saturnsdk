*************************************
*** READ.ME file from release 1.5 ***
*************************************

Files SATCD15.BIN and SATCD25.BIN are the latest versions of the CD
emulator boot code for the Saturn.

These new versions provide the following:

- Fixed bug that prevented playing of CDDA tracks >9

TC - 09.Sep.96

